//alight Motion 
function am() {
  var am = confirm("╭───────────────\n┊ Produk : ALIGHT MOTION\n┊・Stok Tersedia : 100\n┊・Desk : 1 Tahun Sharing, Garansi 3 Bulan!\n╰───────────────\nIngin Memesan? klik oke")
  if (am) {
    window.location = "https://wa.me/62895328184015?text=Mau+Order+Am~"
  } else {
    alert("baiklah, tetap disini ya!")
  }
}
//YouTube 
function yt() {
  var yt = confirm("╭───────────────\n┊ Produk : YouTube Famplan\n┊・Stok Tersedia : 100\n┊・Desk : 1  bulan, garansi 7 hari!\n╰───────────────\nIngin Memesan? klik oke")
  if (yt) {
    window.location = "https://wa.me/62895328184015?text=Mau+Order+YT~"
  } else {
    alert("baiklah, tetap disini ya!")
  }
}
//capcut
function cc() {
  var cc = confirm("╭───────────────\n┊ Produk : CapCut Pro\n┊・Stok Tersedia : 30\n┊・Desk : 1  bulan, garansi 7 hari!\n╰───────────────\nIngin Memesan? klik oke")
  if (cc) {
    window.location = "https://wa.me/62895328184015?text=Mau+Order+cc~"
  } else {
    alert("baiklah, tetap disini ya!")
  }

}
//Spotify
function spo() {
  var spo = confirm("╭───────────────\n┊ Produk : Spotify\n┊・Stok Tersedia : 20\n┊・Desk : 1  bulan, garansi 7 hari!\n╰───────────────\nIngin Memesan? klik oke")
  if (spo) {
    window.location = "https://wa.me/62895328184015?text=Mau+Order+Spotify~"
  } else {
    alert("baiklah, tetap disini ya!")
  }
}
//canva
function cnv() {
  var cnv = confirm("╭───────────────\n┊ Produk : Canva\n┊・Stok Tersedia : 200\n┊・Desk : 1  bulan, garansi 7 hari!\n╰───────────────\nIngin Memesan? klik oke")
  if (cnv) {
    window.location = "https://wa.me/62895328184015?text=Mau+Order+Canva~"
  } else {
    alert("baiklah, tetap disini ya!")
  }
}